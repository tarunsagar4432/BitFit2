package com.example.BitFit

data class DisplayFood(
    val foodName: String?,
    val calories: Double?,
) : java.io.Serializable


